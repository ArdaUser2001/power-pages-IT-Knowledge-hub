(function () {
  "use strict";

  const DB_NAME = "opsbase-local-kb";
  const DB_VERSION = 1;
  const STORE = "articles";
  const META = "meta";
  const CATEGORIES = ["Access & Identity", "Cloud & SaaS", "Hardware", "Networking", "Security", "Servers & Infrastructure", "Software & Applications", "Troubleshooting", "Other IT"];
  const IT_TERMS = new Set(["active directory", "azure", "backup", "bios", "browser", "certificate", "cloud", "computer", "cpu", "database", "dhcp", "directory", "disk", "dns", "domain", "driver", "email", "endpoint", "ethernet", "firewall", "firmware", "gateway", "group policy", "hardware", "helpdesk", "identity", "incident", "internet", "ip address", "laptop", "linux", "macos", "malware", "memory", "microsoft 365", "monitor", "mfa", "multi factor", "network", "office 365", "operating system", "password", "patch", "permission", "printer", "proxy", "ram", "reboot", "remote desktop", "router", "saas", "security", "server", "service desk", "sharepoint", "software", "switch", "ticket", "tls", "troubleshoot", "update", "user account", "virtual machine", "virus", "vpn", "wifi", "wi-fi", "windows"]);
  const TAG_RULES = {
    "access": ["access", "permission", "privilege", "locked out"], "active-directory": ["active directory", "domain controller", "ad account"], "backup": ["backup", "restore", "recovery point"], "cloud": ["cloud", "saas"], "dns": ["dns", "name resolution"], "email": ["email", "mailbox", "outlook"], "hardware": ["hardware", "laptop", "desktop", "monitor", "printer"], "identity": ["identity", "account", "sign in", "login"], "linux": ["linux", "ubuntu", "red hat", "debian"], "m365": ["microsoft 365", "office 365", "m365"], "mfa": ["mfa", "multi-factor", "multifactor", "authenticator"], "networking": ["network", "router", "switch", "gateway", "ethernet"], "password": ["password", "passphrase", "credential"], "printer": ["printer", "print queue", "spooler"], "remote-access": ["remote desktop", "rdp", "remote access"], "security": ["security", "malware", "phishing", "antivirus", "firewall"], "server": ["server", "virtual machine", "vmware", "hyper-v"], "software": ["software", "application", "install", "uninstall"], "troubleshooting": ["troubleshoot", "error", "issue", "problem", "fix"], "vpn": ["vpn", "virtual private network"], "wifi": ["wifi", "wi-fi", "wireless"], "windows": ["windows", "powershell", "registry", "bitlocker"]
  };
  const state = { articles: [], category: "all", tag: "", query: "", sort: "newest", mode: "docx", detailId: null };
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const els = {};
  let db;
  let activeEditor = null;
  let selectedDocxFiles = [];

  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE)) database.createObjectStore(STORE, { keyPath: "id" });
        if (!database.objectStoreNames.contains(META)) database.createObjectStore(META, { keyPath: "key" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function requestResult(request) { return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); }); }
  function makeId() { const bytes = new Uint8Array(16); crypto.getRandomValues(bytes); return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join(""); }
  function bufferToBase64(buffer) { const bytes = new Uint8Array(buffer); let binary = ""; for (let index = 0; index < bytes.length; index += 32768) binary += String.fromCharCode(...bytes.subarray(index, index + 32768)); return btoa(binary); }
  function base64ToBytes(value) { const binary = atob(value); const bytes = new Uint8Array(binary.length); for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index); return bytes; }
  function escapeHtml(value) { const div = document.createElement("div"); div.textContent = value || ""; return div.innerHTML; }
  function textToHtml(value) { return String(value || "").split(/\n{2,}/).map((paragraph) => `<p>${escapeHtml(paragraph).replace(/\n/g, "<br>")}</p>`).join(""); }
  function sanitizeHtml(value) {
    const template = document.createElement("template"); template.innerHTML = value || "";
    const allowed = new Set(["P", "DIV", "BLOCKQUOTE", "BR", "STRONG", "B", "EM", "I", "U", "UL", "OL", "LI", "H1", "H2", "H3", "IMG", "A", "TABLE", "THEAD", "TBODY", "TR", "TH", "TD"]);
    [...template.content.querySelectorAll("*")].forEach((element) => {
      if (!allowed.has(element.tagName)) { element.replaceWith(...element.childNodes); return; }
      const source = element.tagName === "IMG" ? element.getAttribute("src") || "" : "";
      const href = element.tagName === "A" ? element.getAttribute("href") || "" : "";
      [...element.attributes].forEach((attribute) => element.removeAttribute(attribute.name));
      if (element.tagName === "IMG") {
        if (!/^data:image\/(png|jpe?g|gif|webp);base64,/i.test(source)) element.remove();
        else { element.setAttribute("src", source); element.setAttribute("alt", "KB image"); }
      }
      if (element.tagName === "A") {
        if (/^https?:\/\//i.test(href)) { element.setAttribute("href", href); element.setAttribute("rel", "noopener noreferrer"); }
      }
    });
    return template.innerHTML;
  }
  function htmlToText(value) { const template = document.createElement("template"); template.innerHTML = sanitizeHtml(value); return (template.content.textContent || "").replace(/\s+/g, " ").trim(); }
  function articleHtml(article) { return article.contentHtml ? sanitizeHtml(article.contentHtml) : textToHtml(article.content); }
  function templateArticleHtml(sections) { return `<h2>Introduction</h2>${sections.introduction}<h2>Process</h2>${sections.process}<h2>Affected Technology</h2>${sections.technology}`; }
  function resetEditors() { [els.introEditor, els.processEditor, els.technologyEditor].forEach((editor) => { editor.innerHTML = ""; }); activeEditor = els.introEditor; }
  async function loadArticles() { state.articles = await requestResult(db.transaction(STORE, "readonly").objectStore(STORE).getAll()); }
  function highestNumber(articles) { return articles.reduce((max, item) => Math.max(max, Number(String(item.kbNumber || "").replace(/\D/g, "")) || 0), 0); }
  async function nextKbNumber() {
    const tx = db.transaction(META, "readwrite"); const store = tx.objectStore(META); const meta = await requestResult(store.get("nextNumber"));
    const next = Math.max(meta?.value || 1, highestNumber(state.articles) + 1); store.put({ key: "nextNumber", value: next + 1 });
    return `KB-${String(next).padStart(6, "0")}`;
  }
  async function putArticle(article) { const tx = db.transaction(STORE, "readwrite"); tx.objectStore(STORE).put(article); await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); state.articles.push(article); }
  async function deleteArticle(id) { const tx = db.transaction(STORE, "readwrite"); tx.objectStore(STORE).delete(id); await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); state.articles = state.articles.filter((item) => item.id !== id); }
  function normalizeTag(value) { return value.toLowerCase().trim().replace(/^#/, "").replace(/[^a-z0-9+.#-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 28); }
  function extractTags(text, userTags) {
    const haystack = ` ${text.toLowerCase().replace(/\s+/g, " ")} `; const tags = new Set((userTags || "").split(",").map(normalizeTag).filter(Boolean));
    Object.entries(TAG_RULES).forEach(([tag, terms]) => { if (terms.some((term) => haystack.includes(term))) tags.add(tag); });
    return [...tags].slice(0, 10);
  }
  function isItContent(text) { const normalized = text.toLowerCase(); let matches = 0; IT_TERMS.forEach((term) => { if (normalized.includes(term)) matches += 1; }); return matches > 0; }
  function guessCategory(text) {
    const value = text.toLowerCase();
    if (/password|account|identity|permission|mfa|login|sign.in/.test(value)) return "Access & Identity";
    if (/firewall|malware|phishing|security|antivirus|bitlocker|certificate/.test(value)) return "Security";
    if (/router|switch|dns|dhcp|wifi|wi-fi|vpn|network|ip address/.test(value)) return "Networking";
    if (/server|virtual machine|vmware|hyper-v|infrastructure|storage/.test(value)) return "Servers & Infrastructure";
    if (/laptop|desktop|monitor|printer|bios|firmware|hardware/.test(value)) return "Hardware";
    if (/cloud|azure|microsoft 365|office 365|saas|sharepoint/.test(value)) return "Cloud & SaaS";
    if (/software|application|install|uninstall|update/.test(value)) return "Software & Applications";
    if (/error|issue|problem|troubleshoot|fix|reboot/.test(value)) return "Troubleshooting";
    return "Other IT";
  }
  function titleFromFile(filename) { return filename.replace(/\.docx$/i, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().replace(/\b\w/g, (c) => c.toUpperCase()); }
  function deriveTitle(text, filename) { return text.split(/\r?\n/).map((s) => s.trim()).find((s) => s.length >= 4 && s.length <= 140) || titleFromFile(filename) || "Untitled IT article"; }
  function excerpt(text) { const clean = text.replace(/\s+/g, " ").trim(); return clean.slice(0, 190) + (clean.length > 190 ? "…" : ""); }
  function formatDate(value) { return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric" }).format(new Date(value)); }
  function uniqueTags() { const counts = {}; state.articles.forEach((article) => article.tags.forEach((tag) => { counts[tag] = (counts[tag] || 0) + 1; })); return Object.entries(counts).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])); }
  function filteredArticles() {
    const query = state.query.toLowerCase().trim();
    const result = state.articles.filter((article) => (state.category === "all" || article.category === state.category) && (!state.tag || article.tags.includes(state.tag)) && (!query || [article.kbNumber, article.title, article.content, article.category, article.tags.join(" ")].join(" ").toLowerCase().includes(query)));
    result.sort((a, b) => state.sort === "oldest" ? new Date(a.createdAt) - new Date(b.createdAt) : state.sort === "title" ? a.title.localeCompare(b.title) : state.sort === "kb" ? a.kbNumber.localeCompare(b.kbNumber) : new Date(b.createdAt) - new Date(a.createdAt));
    return result;
  }

  function render() {
    const results = filteredArticles(); const categories = CATEGORIES.map((category) => ({ category, count: state.articles.filter((a) => a.category === category).length })).filter((x) => x.count); const tags = uniqueTags();
    els.kbCount.textContent = state.articles.length; els.tagCount.textContent = tags.length; els.allCount.textContent = state.articles.length; els.resultCount.textContent = results.length;
    els.updatedText.textContent = state.articles.length ? `Last updated ${formatDate(Math.max(...state.articles.map((x) => new Date(x.createdAt))))}` : "Ready for your first article";
    els.activeFilterText.textContent = state.tag ? `tagged #${state.tag}` : state.category !== "all" ? `in ${state.category}` : state.query ? "matching your search" : "";
    $$('.filter-item[data-category]').forEach((button) => button.classList.toggle("active", button.dataset.category === state.category));
    els.categoryList.replaceChildren(...categories.map(({ category, count }) => {
      const button = document.createElement("button"); button.className = `filter-item${state.category === category ? " active" : ""}`; button.dataset.category = category;
      const name = document.createElement("span"); name.textContent = category; const badge = document.createElement("b"); badge.textContent = count; button.append(name, badge);
      button.addEventListener("click", () => { state.category = category; render(); }); return button;
    }));
    if (tags.length) els.tagCloud.replaceChildren(...tags.slice(0, 14).map(([tag, count]) => { const button = document.createElement("button"); button.className = `tag-chip${state.tag === tag ? " active" : ""}`; button.textContent = `#${tag} ${count}`; button.addEventListener("click", () => { state.tag = state.tag === tag ? "" : tag; render(); }); return button; }));
    else { const small = document.createElement("small"); small.textContent = "Tags appear after you add a KB."; els.tagCloud.replaceChildren(small); }
    els.articleList.replaceChildren(...results.map(createArticleCard)); const shouldShowEmpty = results.length === 0; els.emptyState.hidden = !shouldShowEmpty; els.articleList.hidden = shouldShowEmpty;
    els.emptyState.querySelector("h2").textContent = state.articles.length && shouldShowEmpty ? "No matching articles" : "Build your IT playbook";
    els.emptyState.querySelector("p").textContent = state.articles.length && shouldShowEmpty ? "Try another search, tag or category." : "Import a Word document with its images, or create an illustrated article with the Process KB template. OpsBase assigns a permanent KB number and suggests reusable tags.";
  }
  function createArticleCard(article) {
    const card = document.createElement("article"); card.className = "article-card"; card.tabIndex = 0; card.setAttribute("aria-label", `Open ${article.kbNumber}: ${article.title}`);
    const body = document.createElement("div"), top = document.createElement("div"); top.className = "card-top"; const number = document.createElement("span"); number.className = "kb-number"; number.textContent = article.kbNumber; const category = document.createElement("span"); category.className = "category-pill"; category.textContent = article.category; top.append(number, category);
    const title = document.createElement("h3"); title.textContent = article.title; const summary = document.createElement("p"); summary.textContent = excerpt(article.content); const tags = document.createElement("div"); tags.className = "card-tags"; article.tags.forEach((tag) => { const item = document.createElement("span"); item.textContent = `#${tag}`; tags.append(item); }); body.append(top, title, summary, tags);
    const date = document.createElement("time"); date.className = "card-date"; date.textContent = formatDate(article.createdAt); date.dateTime = article.createdAt; card.append(body, date);
    card.addEventListener("click", () => openDetail(article.id)); card.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openDetail(article.id); } }); return card;
  }

  function openAddDialog() { els.formMessage.textContent = ""; els.addDialog.showModal(); }
  function setMode(mode) { state.mode = mode; $$('.mode-tabs button').forEach((button) => { const active = button.dataset.mode === mode; button.classList.toggle("active", active); button.setAttribute("aria-selected", String(active)); }); els.docxPanel.hidden = mode !== "docx"; els.manualPanel.hidden = mode !== "manual"; els.saveButton.textContent = mode === "docx" ? "Import article" : "Save article"; }
  function selectDocxFiles(files, source) {
    const available = [...files];
    selectedDocxFiles = available.filter((file) => file.name.toLowerCase().endsWith(".docx") && !file.name.startsWith("~$"));
    renderFileQueue(source, available.length - selectedDocxFiles.length);
  }
  function renderFileQueue(source = "files", skipped = 0) {
    els.queueSummary.textContent = selectedDocxFiles.length ? `${selectedDocxFiles.length} Word KB${selectedDocxFiles.length === 1 ? "" : "s"} selected from ${source}${skipped ? ` · ${skipped} non-Word or temporary file${skipped === 1 ? "" : "s"} skipped` : ""}` : skipped ? "No .docx KB files were found in that selection." : "";
    els.fileQueue.replaceChildren(...selectedDocxFiles.map((file) => { const row = document.createElement("div"), name = document.createElement("span"), size = document.createElement("span"); name.textContent = file.webkitRelativePath || file.name; name.title = name.textContent; size.textContent = `${Math.max(1, Math.round(file.size / 1024))} KB`; row.append(name, size); return row; }));
  }
  function insertHtmlAtSelection(editor, html) { editor.focus(); const selection = window.getSelection(); if (!selection.rangeCount || !editor.contains(selection.anchorNode)) { editor.insertAdjacentHTML("beforeend", html); return; } const range = selection.getRangeAt(0); range.deleteContents(); const fragment = range.createContextualFragment(html); range.insertNode(fragment); range.collapse(false); selection.removeAllRanges(); selection.addRange(range); }
  async function imageFileToDataUrl(file) {
    if (!file.type.startsWith("image/")) throw new Error("Choose an image file.");
    if (file.size > 10 * 1024 * 1024) throw new Error("Images must be smaller than 10 MB.");
    const source = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
    if (/^data:image\/(png|jpe?g|gif);/i.test(source)) return source;
    const image = await loadImage(source); const canvas = document.createElement("canvas"); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight; canvas.getContext("2d").drawImage(image, 0, 0); return canvas.toDataURL("image/png");
  }
  async function insertEditorImage(file) { try { const source = await imageFileToDataUrl(file); insertHtmlAtSelection(activeEditor || els.processEditor, `<img src="${source}" alt="KB screenshot">`); } catch (error) { showToast(error.message || "Image could not be added"); } finally { els.editorImageInput.value = ""; } }
  function handleEditorPaste(event) { const imageItem = [...(event.clipboardData?.items || [])].find((item) => item.type.startsWith("image/")); if (!imageItem) return; event.preventDefault(); activeEditor = event.currentTarget; insertEditorImage(imageItem.getAsFile()); }
  async function readDocx(file) {
    if (!window.mammoth) throw new Error("The bundled Word reader could not load.");
    const arrayBuffer = await file.arrayBuffer();
    const [rawResult, htmlResult] = await Promise.all([
      window.mammoth.extractRawText({ arrayBuffer }),
      window.mammoth.convertToHtml({ arrayBuffer }, { convertImage: window.mammoth.images.imgElement((image) => image.read("base64").then((data) => ({ src: `data:${image.contentType};base64,${data}`, alt: "KB image" }))) }),
    ]);
    const text = rawResult.value.replace(/\n{3,}/g, "\n\n").trim();
    if (!text) throw new Error(`${file.name} contains no readable text.`);
    return { text, html: sanitizeHtml(htmlResult.value), originalDocxData: bufferToBase64(arrayBuffer) };
  }
  async function handleSubmit(event) {
    event.preventDefault(); els.formMessage.textContent = ""; els.saveButton.disabled = true;
    try {
      const manualTags = els.manualTags.value;
      if (state.mode === "docx") {
        const files = selectedDocxFiles; if (!files.length) throw new Error("Choose at least one .docx file or a folder containing Word KBs."); const prepared = [];
        for (const file of files) { if (!file.name.toLowerCase().endsWith(".docx")) throw new Error(`${file.name} is not a .docx file.`); const documentData = await readDocx(file); prepared.push({ file, ...documentData }); }
        for (const { file, text, html, originalDocxData } of prepared) await putArticle({ id: makeId(), kbNumber: await nextKbNumber(), title: deriveTitle(text, file.name), content: text, contentHtml: html, category: els.categoryInput.value === "auto" ? guessCategory(text) : els.categoryInput.value, tags: extractTags(`${file.name} ${text}`, manualTags), sourceFile: file.webkitRelativePath || file.name, originalDocxData, createdAt: new Date().toISOString() });
        showToast(`${prepared.length} article${prepared.length === 1 ? "" : "s"} imported`);
      } else {
        const title = els.manualTitle.value.trim();
        const sections = { introduction: sanitizeHtml(els.introEditor.innerHTML), process: sanitizeHtml(els.processEditor.innerHTML), technology: sanitizeHtml(els.technologyEditor.innerHTML) };
        const contentHtml = templateArticleHtml(sections); const content = htmlToText(contentHtml);
        if (!title || !content) throw new Error("Add a title and content to at least one template section."); if (!isItContent(`${title} ${content}`)) throw new Error("This does not appear to be an IT article. Add IT-specific details and try again.");
        const article = { id: makeId(), kbNumber: await nextKbNumber(), title, content, contentHtml, templateSections: sections, category: els.categoryInput.value === "auto" ? guessCategory(`${title} ${content}`) : els.categoryInput.value, tags: extractTags(`${title} ${content}`, manualTags), sourceFile: null, originalDocxData: null, createdAt: new Date().toISOString() }; await putArticle(article); showToast(`${article.kbNumber} saved`);
      }
      els.addForm.reset(); resetEditors(); selectedDocxFiles = []; renderFileQueue(); els.categoryInput.value = "auto"; els.addDialog.close(); render();
    } catch (error) { els.formMessage.textContent = error.message || "The article could not be added."; } finally { els.saveButton.disabled = false; }
  }
  function openDetail(id) { const article = state.articles.find((item) => item.id === id); if (!article) return; state.detailId = id; els.detailNumber.textContent = article.kbNumber; els.detailTitle.textContent = article.title; els.detailContent.innerHTML = articleHtml(article); const items = [article.category, ...article.tags.map((tag) => `#${tag}`), `Added ${formatDate(article.createdAt)}`]; if (article.sourceFile) items.push(article.sourceFile); els.detailMeta.replaceChildren(...items.map((value) => { const span = document.createElement("span"); span.textContent = value; return span; })); els.exportOriginalButton.disabled = !article.originalDocxData; els.exportOriginalButton.title = article.originalDocxData ? `Download ${article.sourceFile}` : "The original file was not retained for this article"; els.articleDialog.showModal(); }
  async function removeCurrentArticle() { const article = state.articles.find((item) => item.id === state.detailId); if (!article || !confirm(`Delete ${article.kbNumber} — ${article.title}?\n\nThis cannot be undone unless you have a backup.`)) return; await deleteArticle(article.id); els.articleDialog.close(); render(); showToast(`${article.kbNumber} deleted`); }
  async function copyCurrentArticle() { const article = state.articles.find((item) => item.id === state.detailId); if (!article) return; const text = `${article.kbNumber} — ${article.title}\nCategory: ${article.category}\nTags: ${article.tags.join(", ")}\n\n${article.content}`; try { await navigator.clipboard.writeText(text); showToast("Article copied"); } catch { showToast("Copy was blocked by the browser"); } }
  function safeFilename(value) { return value.replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim().slice(0, 120) || "knowledge-article"; }
  function downloadBlob(blob, filename) { const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1500); }
  function loadImage(source) { return new Promise((resolve, reject) => { const image = new Image(); image.onload = () => resolve(image); image.onerror = reject; image.src = source; }); }
  function sectionsForArticle(article) {
    if (article.templateSections) return article.templateSections;
    const firstParagraph = article.content.split(/\n{2,}/).find(Boolean) || excerpt(article.content);
    return { introduction: `<p>${escapeHtml(firstParagraph)}</p>`, process: articleHtml(article), technology: `<p>${escapeHtml([article.category, ...article.tags].join(", "))}</p>` };
  }
  function inlineRuns(node, inherited = {}) {
    const d = window.docx;
    if (node.nodeType === Node.TEXT_NODE) return node.textContent ? [new d.TextRun({ text: node.textContent, ...inherited })] : [];
    if (node.nodeType !== Node.ELEMENT_NODE || node.tagName === "IMG") return [];
    if (node.tagName === "BR") return [new d.TextRun({ break: 1 })];
    const formatting = { ...inherited };
    if (["STRONG", "B"].includes(node.tagName)) formatting.bold = true;
    if (["EM", "I"].includes(node.tagName)) formatting.italics = true;
    if (node.tagName === "U") formatting.underline = { type: d.UnderlineType.SINGLE };
    return [...node.childNodes].flatMap((child) => inlineRuns(child, formatting));
  }
  async function imageParagraph(source) {
    const d = window.docx; const match = source.match(/^data:image\/(png|jpe?g|gif|webp);base64,(.+)$/i); if (!match) return null;
    let dataSource = source; let type = match[1].toLowerCase().replace("jpeg", "jpg");
    if (type === "webp") { const image = await loadImage(source); const canvas = document.createElement("canvas"); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight; canvas.getContext("2d").drawImage(image, 0, 0); dataSource = canvas.toDataURL("image/png"); type = "png"; }
    const image = await loadImage(dataSource); const maximumWidth = 600; const width = Math.max(1, Math.min(maximumWidth, image.naturalWidth)); const height = Math.max(1, Math.round(width * image.naturalHeight / image.naturalWidth)); const encoded = dataSource.split(",")[1];
    return new d.Paragraph({ alignment: d.AlignmentType.CENTER, spacing: { before: 160, after: 200 }, children: [new d.ImageRun({ data: base64ToBytes(encoded), type, transformation: { width, height }, altText: { title: "KB image", description: "Image included in knowledge article", name: "KB image" } })] });
  }
  async function htmlToDocumentChildren(html) {
    const d = window.docx; const template = document.createElement("template"); template.innerHTML = sanitizeHtml(html); const output = [];
    const appendBlock = async (node, listType = null) => {
      if (node.nodeType === Node.TEXT_NODE) { if (node.textContent.trim()) output.push(new d.Paragraph({ children: [new d.TextRun(node.textContent)] })); return; }
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      if (node.tagName === "IMG") { const image = await imageParagraph(node.getAttribute("src")); if (image) output.push(image); return; }
      if (["UL", "OL"].includes(node.tagName)) { for (const item of [...node.children].filter((child) => child.tagName === "LI")) await appendBlock(item, node.tagName); return; }
      if (node.tagName === "TABLE") { for (const row of node.querySelectorAll("tr")) { const text = [...row.children].map((cell) => cell.textContent.trim()).join("    "); if (text) output.push(new d.Paragraph({ children: [new d.TextRun(text)] })); } return; }
      const images = [...node.querySelectorAll(":scope > img")]; const runs = inlineRuns(node);
      const paragraphOptions = { children: runs.length ? runs : [new d.TextRun("")] };
      if (node.tagName === "LI") { if (listType === "OL") paragraphOptions.numbering = { reference: "kb-numbering", level: 0 }; else paragraphOptions.bullet = { level: 0 }; }
      if (["H1", "H2", "H3"].includes(node.tagName)) paragraphOptions.style = "ProcessSubheading";
      if (node.textContent.trim()) output.push(new d.Paragraph(paragraphOptions));
      for (const imageNode of images) { const image = await imageParagraph(imageNode.getAttribute("src")); if (image) output.push(image); }
      for (const nestedList of [...node.children].filter((child) => ["UL", "OL"].includes(child.tagName))) await appendBlock(nestedList);
    };
    for (const node of [...template.content.childNodes]) await appendBlock(node);
    return output.length ? output : [new d.Paragraph("")];
  }
  async function buildTemplateDocx(article) {
    if (!window.docx) throw new Error("The bundled Word exporter could not load.");
    const d = window.docx; const sections = sectionsForArticle(article);
    const children = [
      new d.Paragraph({ style: "ProcessTitle", children: [new d.TextRun(article.title)] }),
      new d.Paragraph({ style: "ProcessHeading", children: [new d.TextRun("Introduction")] }),
      ...await htmlToDocumentChildren(sections.introduction),
      new d.Paragraph({ style: "ProcessHeading", children: [new d.TextRun("Process")] }),
      ...await htmlToDocumentChildren(sections.process),
      new d.Paragraph({ style: "ProcessHeading", children: [new d.TextRun("Affected Technology")] }),
      ...await htmlToDocumentChildren(sections.technology),
    ];
    const documentFile = new d.Document({
      creator: "OpsBase", title: `${article.kbNumber} - ${article.title}`, description: "IT knowledge article exported from OpsBase",
      numbering: { config: [{ reference: "kb-numbering", levels: [{ level: 0, format: d.LevelFormat.DECIMAL, text: "%1.", alignment: d.AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }] },
      styles: {
        default: { document: { run: { font: "Futura BT Light", size: 22, color: "000000" }, paragraph: { spacing: { after: 200, line: 288 } } } },
        paragraphStyles: [
          { id: "ProcessTitle", name: "Process Title", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Futura BT Light", size: 36, bold: true, color: "165F66" }, paragraph: { spacing: { after: 240 }, border: { bottom: { style: d.BorderStyle.SINGLE, color: "0A5D66", size: 36, space: 1 } }, keepNext: true } },
          { id: "ProcessHeading", name: "Process Heading", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Futura BT Light", size: 26, bold: true, color: "165F66" }, paragraph: { spacing: { before: 360, after: 180 }, keepNext: true } },
          { id: "ProcessSubheading", name: "Process Subheading", basedOn: "Normal", next: "Normal", run: { font: "Futura BT Light", size: 22, bold: true, color: "165F66" }, paragraph: { spacing: { before: 220, after: 100 }, keepNext: true } },
        ],
      },
      sections: [{ properties: { page: { size: { width: 11907, height: 16839 }, margin: { top: 1135, right: 1080, bottom: 1134, left: 1080, header: 720, footer: 720 } } }, footers: { default: new d.Footer({ children: [new d.Paragraph({ alignment: d.AlignmentType.CENTER, children: [new d.TextRun({ color: "165F66", size: 18, children: [d.PageNumber.CURRENT] })] })] }) }, children }],
    });
    return d.Packer.toBlob(documentFile);
  }
  function exportOriginalDocx() { const article = state.articles.find((item) => item.id === state.detailId); if (!article?.originalDocxData) return; downloadBlob(new Blob([base64ToBytes(article.originalDocxData)], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }), safeFilename(article.sourceFile || `${article.kbNumber}-${article.title}.docx`)); showToast("Original Word file exported"); }
  async function exportTemplateDocx() { const article = state.articles.find((item) => item.id === state.detailId); if (!article) return; els.exportTemplateButton.disabled = true; try { downloadBlob(await buildTemplateDocx(article), `${article.kbNumber}-${safeFilename(article.title)}-Process-KB.docx`); showToast("Template Word file exported"); } catch (error) { console.error(error); showToast(error.message || "Word export failed"); } finally { els.exportTemplateButton.disabled = false; } }
  function exportBackup() { const payload = { app: "OpsBase", version: 2, exportedAt: new Date().toISOString(), nextNumber: highestNumber(state.articles) + 1, articles: state.articles }; const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }); const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `opsbase-backup-${new Date().toISOString().slice(0, 10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1000); closeBackupMenu(); showToast("Backup exported"); }
  async function restoreBackup(file) {
    try {
      const payload = JSON.parse(await file.text()); if (payload.app !== "OpsBase" || !Array.isArray(payload.articles)) throw new Error("This is not a valid OpsBase backup."); if (!confirm(`Replace the current library with ${payload.articles.length} backed-up article${payload.articles.length === 1 ? "" : "s"}?`)) return;
      const valid = payload.articles.filter((x) => x && typeof x.id === "string" && typeof x.kbNumber === "string" && typeof x.title === "string" && typeof x.content === "string" && CATEGORIES.includes(x.category) && Array.isArray(x.tags)); if (valid.length !== payload.articles.length) throw new Error("The backup contains invalid article data.");
      const tx = db.transaction([STORE, META], "readwrite"), store = tx.objectStore(STORE); store.clear(); valid.forEach((item) => store.put(item)); tx.objectStore(META).put({ key: "nextNumber", value: Math.max(payload.nextNumber || 1, highestNumber(valid) + 1) }); await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); await loadArticles(); render(); showToast("Backup restored");
    } catch (error) { showToast(error.message || "Backup could not be restored"); } finally { els.backupFileInput.value = ""; }
  }
  function closeBackupMenu() { els.backupMenu.hidden = true; els.backupMenuButton.setAttribute("aria-expanded", "false"); }
  function showToast(message) { els.toast.textContent = message; els.toast.classList.add("show"); clearTimeout(showToast.timer); showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 2300); }
  function bindEvents() {
    [els.addButton, els.secondaryAddButton, els.emptyAddButton].forEach((button) => button.addEventListener("click", openAddDialog)); els.addClose.addEventListener("click", () => els.addDialog.close()); els.cancelAddButton.addEventListener("click", () => els.addDialog.close()); $$('.mode-tabs button').forEach((button) => button.addEventListener("click", () => setMode(button.dataset.mode))); els.docxInput.addEventListener("change", () => selectDocxFiles(els.docxInput.files, "individual files")); els.folderButton.addEventListener("click", () => els.folderInput.click()); els.folderInput.addEventListener("change", () => selectDocxFiles(els.folderInput.files, "the selected folder"));
    $$('.rich-editor').forEach((editor) => { editor.addEventListener("focus", () => { activeEditor = editor; }); editor.addEventListener("paste", handleEditorPaste); });
    $$('.editor-toolbar button').forEach((button) => { button.addEventListener("mousedown", (event) => event.preventDefault()); button.addEventListener("click", () => { activeEditor = button.closest(".template-section").querySelector(".rich-editor"); activeEditor.focus(); if (button.dataset.command === "image") els.editorImageInput.click(); else document.execCommand(button.dataset.command, false); }); });
    els.editorImageInput.addEventListener("change", () => { if (els.editorImageInput.files[0]) insertEditorImage(els.editorImageInput.files[0]); });
    ["dragenter", "dragover"].forEach((name) => els.dropZone.addEventListener(name, (event) => { event.preventDefault(); els.dropZone.classList.add("dragging"); })); ["dragleave", "drop"].forEach((name) => els.dropZone.addEventListener(name, (event) => { event.preventDefault(); els.dropZone.classList.remove("dragging"); })); els.dropZone.addEventListener("drop", (event) => { if (event.dataTransfer.files.length) selectDocxFiles(event.dataTransfer.files, "dropped files"); });
    els.addForm.addEventListener("submit", handleSubmit); els.searchInput.addEventListener("input", () => { state.query = els.searchInput.value; render(); }); els.sortSelect.addEventListener("change", () => { state.sort = els.sortSelect.value; render(); }); $('.filter-item[data-category="all"]').addEventListener("click", () => { state.category = "all"; render(); }); els.clearFilters.addEventListener("click", () => { state.category = "all"; state.tag = ""; state.query = ""; els.searchInput.value = ""; render(); }); document.addEventListener("keydown", (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); els.searchInput.focus(); } });
    els.detailClose.addEventListener("click", () => els.articleDialog.close()); els.deleteButton.addEventListener("click", removeCurrentArticle); els.copyButton.addEventListener("click", copyCurrentArticle); els.exportOriginalButton.addEventListener("click", exportOriginalDocx); els.exportTemplateButton.addEventListener("click", exportTemplateDocx); els.backupMenuButton.addEventListener("click", () => { const opening = els.backupMenu.hidden; els.backupMenu.hidden = !opening; els.backupMenuButton.setAttribute("aria-expanded", String(opening)); }); els.exportButton.addEventListener("click", exportBackup); els.importButton.addEventListener("click", () => { closeBackupMenu(); els.backupFileInput.click(); }); els.backupFileInput.addEventListener("change", () => { if (els.backupFileInput.files[0]) restoreBackup(els.backupFileInput.files[0]); }); document.addEventListener("click", (event) => { if (!els.backupMenu.contains(event.target) && event.target !== els.backupMenuButton) closeBackupMenu(); });
  }
  async function init() {
    ["kbCount", "tagCount", "updatedText", "allCount", "categoryList", "tagCloud", "searchInput", "sortSelect", "resultCount", "activeFilterText", "articleList", "emptyState", "addButton", "secondaryAddButton", "emptyAddButton", "clearFilters", "addDialog", "addForm", "addClose", "cancelAddButton", "docxPanel", "manualPanel", "docxInput", "folderButton", "folderInput", "dropZone", "queueSummary", "fileQueue", "manualTitle", "introEditor", "processEditor", "technologyEditor", "editorImageInput", "categoryInput", "manualTags", "formMessage", "saveButton", "articleDialog", "detailNumber", "detailTitle", "detailMeta", "detailContent", "detailClose", "deleteButton", "copyButton", "exportOriginalButton", "exportTemplateButton", "backupMenuButton", "backupMenu", "exportButton", "importButton", "backupFileInput", "toast"].forEach((id) => { els[id] = document.getElementById(id); });
    CATEGORIES.forEach((category) => { const option = document.createElement("option"); option.value = category; option.textContent = category; els.categoryInput.append(option); }); const auto = document.createElement("option"); auto.value = "auto"; auto.textContent = "Auto-detect"; els.categoryInput.prepend(auto); els.categoryInput.value = "auto";
    try { db = await openDatabase(); await loadArticles(); activeEditor = els.introEditor; bindEvents(); render(); } catch (error) { console.error(error); alert("OpsBase could not open local browser storage. Check that private browsing is off and reload the page."); }
  }
  init();
})();
