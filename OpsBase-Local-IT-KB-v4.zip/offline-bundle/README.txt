OPSBASE — LOCAL IT KNOWLEDGE BASE
=================================

START
1. Keep this entire folder together.
2. Double-click index.html to open OpsBase in a current version of Chrome,
   Edge, Firefox, or Safari.
3. Choose "Add knowledge" to import one or more .docx files or create an
   article with the Process KB template editor.
4. To import a collection at once, choose "Choose a KB folder". OpsBase finds
   .docx files in that folder and its subfolders and skips unrelated files.
5. Imported .docx files do not need to follow the Process KB template. Any
   readable Word layout can be added and searched.

IMAGES AND WORD EXPORTS
- Images embedded in newly imported Word documents appear with the KB.
- In the Process template editor, use the Image buttons or paste a screenshot
  directly into a section.
- Open any KB to export it in Process-template .docx format.
- Newly imported .docx files can also be downloaded again in their unchanged
  original form. Articles added with an earlier OpsBase version do not contain
  the original file bytes, but they can still be exported in template format.

YOUR DATA
- Articles, images, and retained source files are stored in this browser on
  this device. No server or internet
  connection is used.
- Each article gets a permanent sequential number such as KB-000001.
- Removing an article does not reuse its KB number.
- Use the three-dot menu to export a JSON backup regularly.
- Restoring a backup replaces the library currently stored in that browser.

IMPORTANT
- Browser storage belongs to the exact browser and location used to open the
  app. Moving the folder or using a different browser can show a separate,
  empty library. Export a backup before moving it.
- Clearing site/browser data can remove the library. Keep backup files in a
  safe location.
- Word import supports .docx files. Legacy .doc files should first be saved as
  .docx in Microsoft Word or LibreOffice.
