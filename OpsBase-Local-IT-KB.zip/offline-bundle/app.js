(function () {
  "use strict";

  const DB_NAME = "opsbase-local-kb";
  const DB_VERSION = 1;
  const STORE = "articles";
  const META = "meta";
  const CATEGORIES = ["Access & Identity", "Cloud & SaaS", "Hardware", "Networking", "Security", "Servers & Infrastructure", "Software & Applications", "Troubleshooting", "Other IT"];
  const IT_TERMS = new Set(["active directory", "azure", "backup", "bios", "browser", "certificate", "cloud", "computer", "cpu", "database", "dhcp", "directory", "disk", "dns", "domain", "driver", "email", "endpoint", "ethernet", "firewall", "firmware", "gateway", "group policy", "hardware", "helpdesk", "identity", "incident", "internet", "ip address", "laptop", "linux", "macos", "malware", "memory", "microsoft 365", "monitor", "mfa", "multi factor", "network", "office 365", "operating system", "password", "patch", "permission", "printer", "proxy", "ram", "reboot", "remote desktop", "router", "saas", "security", "server", "service desk", "sharepoint", "software", "switch", "ticket", "tls", "troubleshoot", "update", "user account", "virtual machine", "virus", "vpn", "wifi", "wi-fi", "windows"]);
  const TAG_RULES = {
    "access": ["access", "permission", "privilege", "locked out"], "active-directory": ["active directory", "domain controller", "ad account"], "backup": ["backup", "restore", "recovery point"], "cloud": ["cloud", "saas"], "dns": ["dns", "name resolution"], "email": ["email", "mailbox", "outlook"], "hardware": ["hardware", "laptop", "desktop", "monitor", "printer"], "identity": ["identity", "account", "sign in", "login"], "linux": ["linux", "ubuntu", "red hat", "debian"], "m365": ["microsoft 365", "office 365", "m365"], "mfa": ["mfa", "multi-factor", "multifactor", "authenticator"], "networking": ["network", "router", "switch", "gateway", "ethernet"], "password": ["password", "passphrase", "credential"], "printer": ["printer", "print queue", "spooler"], "remote-access": ["remote desktop", "rdp", "remote access"], "security": ["security", "malware", "phishing", "antivirus", "firewall"], "server": ["server", "virtual machine", "vmware", "hyper-v"], "software": ["software", "application", "install", "uninstall"], "troubleshooting": ["troubleshoot", "error", "issue", "problem", "fix"], "vpn": ["vpn", "virtual private network"], "wifi": ["wifi", "wi-fi", "wireless"], "windows": ["windows", "powershell", "registry", "bitlocker"]
  };
  const state = { articles: [], category: "all", tag: "", query: "", sort: "newest", mode: "docx", detailId: null };
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const els = {};
  let db;

  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE)) database.createObjectStore(STORE, { keyPath: "id" });
        if (!database.objectStoreNames.contains(META)) database.createObjectStore(META, { keyPath: "key" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function requestResult(request) { return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); }); }
  function makeId() { const bytes = new Uint8Array(16); crypto.getRandomValues(bytes); return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join(""); }
  async function loadArticles() { state.articles = await requestResult(db.transaction(STORE, "readonly").objectStore(STORE).getAll()); }
  function highestNumber(articles) { return articles.reduce((max, item) => Math.max(max, Number(String(item.kbNumber || "").replace(/\D/g, "")) || 0), 0); }
  async function nextKbNumber() {
    const tx = db.transaction(META, "readwrite"); const store = tx.objectStore(META); const meta = await requestResult(store.get("nextNumber"));
    const next = Math.max(meta?.value || 1, highestNumber(state.articles) + 1); store.put({ key: "nextNumber", value: next + 1 });
    return `KB-${String(next).padStart(6, "0")}`;
  }
  async function putArticle(article) { const tx = db.transaction(STORE, "readwrite"); tx.objectStore(STORE).put(article); await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); state.articles.push(article); }
  async function deleteArticle(id) { const tx = db.transaction(STORE, "readwrite"); tx.objectStore(STORE).delete(id); await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); state.articles = state.articles.filter((item) => item.id !== id); }
  function normalizeTag(value) { return value.toLowerCase().trim().replace(/^#/, "").replace(/[^a-z0-9+.#-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 28); }
  function extractTags(text, userTags) {
    const haystack = ` ${text.toLowerCase().replace(/\s+/g, " ")} `; const tags = new Set((userTags || "").split(",").map(normalizeTag).filter(Boolean));
    Object.entries(TAG_RULES).forEach(([tag, terms]) => { if (terms.some((term) => haystack.includes(term))) tags.add(tag); });
    return [...tags].slice(0, 10);
  }
  function isItContent(text) { const normalized = text.toLowerCase(); let matches = 0; IT_TERMS.forEach((term) => { if (normalized.includes(term)) matches += 1; }); return matches > 0; }
  function guessCategory(text) {
    const value = text.toLowerCase();
    if (/password|account|identity|permission|mfa|login|sign.in/.test(value)) return "Access & Identity";
    if (/firewall|malware|phishing|security|antivirus|bitlocker|certificate/.test(value)) return "Security";
    if (/router|switch|dns|dhcp|wifi|wi-fi|vpn|network|ip address/.test(value)) return "Networking";
    if (/server|virtual machine|vmware|hyper-v|infrastructure|storage/.test(value)) return "Servers & Infrastructure";
    if (/laptop|desktop|monitor|printer|bios|firmware|hardware/.test(value)) return "Hardware";
    if (/cloud|azure|microsoft 365|office 365|saas|sharepoint/.test(value)) return "Cloud & SaaS";
    if (/software|application|install|uninstall|update/.test(value)) return "Software & Applications";
    if (/error|issue|problem|troubleshoot|fix|reboot/.test(value)) return "Troubleshooting";
    return "Other IT";
  }
  function titleFromFile(filename) { return filename.replace(/\.docx$/i, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().replace(/\b\w/g, (c) => c.toUpperCase()); }
  function deriveTitle(text, filename) { return text.split(/\r?\n/).map((s) => s.trim()).find((s) => s.length >= 4 && s.length <= 140) || titleFromFile(filename) || "Untitled IT article"; }
  function excerpt(text) { const clean = text.replace(/\s+/g, " ").trim(); return clean.slice(0, 190) + (clean.length > 190 ? "…" : ""); }
  function formatDate(value) { return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric" }).format(new Date(value)); }
  function uniqueTags() { const counts = {}; state.articles.forEach((article) => article.tags.forEach((tag) => { counts[tag] = (counts[tag] || 0) + 1; })); return Object.entries(counts).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])); }
  function filteredArticles() {
    const query = state.query.toLowerCase().trim();
    const result = state.articles.filter((article) => (state.category === "all" || article.category === state.category) && (!state.tag || article.tags.includes(state.tag)) && (!query || [article.kbNumber, article.title, article.content, article.category, article.tags.join(" ")].join(" ").toLowerCase().includes(query)));
    result.sort((a, b) => state.sort === "oldest" ? new Date(a.createdAt) - new Date(b.createdAt) : state.sort === "title" ? a.title.localeCompare(b.title) : state.sort === "kb" ? a.kbNumber.localeCompare(b.kbNumber) : new Date(b.createdAt) - new Date(a.createdAt));
    return result;
  }

  function render() {
    const results = filteredArticles(); const categories = CATEGORIES.map((category) => ({ category, count: state.articles.filter((a) => a.category === category).length })).filter((x) => x.count); const tags = uniqueTags();
    els.kbCount.textContent = state.articles.length; els.tagCount.textContent = tags.length; els.allCount.textContent = state.articles.length; els.resultCount.textContent = results.length;
    els.updatedText.textContent = state.articles.length ? `Last updated ${formatDate(Math.max(...state.articles.map((x) => new Date(x.createdAt))))}` : "Ready for your first article";
    els.activeFilterText.textContent = state.tag ? `tagged #${state.tag}` : state.category !== "all" ? `in ${state.category}` : state.query ? "matching your search" : "";
    $$('.filter-item[data-category]').forEach((button) => button.classList.toggle("active", button.dataset.category === state.category));
    els.categoryList.replaceChildren(...categories.map(({ category, count }) => {
      const button = document.createElement("button"); button.className = `filter-item${state.category === category ? " active" : ""}`; button.dataset.category = category;
      const name = document.createElement("span"); name.textContent = category; const badge = document.createElement("b"); badge.textContent = count; button.append(name, badge);
      button.addEventListener("click", () => { state.category = category; render(); }); return button;
    }));
    if (tags.length) els.tagCloud.replaceChildren(...tags.slice(0, 14).map(([tag, count]) => { const button = document.createElement("button"); button.className = `tag-chip${state.tag === tag ? " active" : ""}`; button.textContent = `#${tag} ${count}`; button.addEventListener("click", () => { state.tag = state.tag === tag ? "" : tag; render(); }); return button; }));
    else { const small = document.createElement("small"); small.textContent = "Tags appear after you add a KB."; els.tagCloud.replaceChildren(small); }
    els.articleList.replaceChildren(...results.map(createArticleCard)); const shouldShowEmpty = results.length === 0; els.emptyState.hidden = !shouldShowEmpty; els.articleList.hidden = shouldShowEmpty;
    els.emptyState.querySelector("h2").textContent = state.articles.length && shouldShowEmpty ? "No matching articles" : "Build your IT playbook";
    els.emptyState.querySelector("p").textContent = state.articles.length && shouldShowEmpty ? "Try another search, tag or category." : "Import a Word document or write an article. OpsBase extracts the text, assigns a permanent KB number, and suggests reusable tags.";
  }
  function createArticleCard(article) {
    const card = document.createElement("article"); card.className = "article-card"; card.tabIndex = 0; card.setAttribute("aria-label", `Open ${article.kbNumber}: ${article.title}`);
    const body = document.createElement("div"), top = document.createElement("div"); top.className = "card-top"; const number = document.createElement("span"); number.className = "kb-number"; number.textContent = article.kbNumber; const category = document.createElement("span"); category.className = "category-pill"; category.textContent = article.category; top.append(number, category);
    const title = document.createElement("h3"); title.textContent = article.title; const summary = document.createElement("p"); summary.textContent = excerpt(article.content); const tags = document.createElement("div"); tags.className = "card-tags"; article.tags.forEach((tag) => { const item = document.createElement("span"); item.textContent = `#${tag}`; tags.append(item); }); body.append(top, title, summary, tags);
    const date = document.createElement("time"); date.className = "card-date"; date.textContent = formatDate(article.createdAt); date.dateTime = article.createdAt; card.append(body, date);
    card.addEventListener("click", () => openDetail(article.id)); card.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openDetail(article.id); } }); return card;
  }

  function openAddDialog() { els.formMessage.textContent = ""; els.addDialog.showModal(); }
  function setMode(mode) { state.mode = mode; $$('.mode-tabs button').forEach((button) => { const active = button.dataset.mode === mode; button.classList.toggle("active", active); button.setAttribute("aria-selected", String(active)); }); els.docxPanel.hidden = mode !== "docx"; els.manualPanel.hidden = mode !== "manual"; els.saveButton.textContent = mode === "docx" ? "Import article" : "Save article"; }
  function renderFileQueue() { els.fileQueue.replaceChildren(...[...els.docxInput.files].map((file) => { const row = document.createElement("div"), name = document.createElement("span"), size = document.createElement("span"); name.textContent = file.name; size.textContent = `${Math.max(1, Math.round(file.size / 1024))} KB`; row.append(name, size); return row; })); }
  async function readDocx(file) { if (!window.mammoth) throw new Error("The bundled Word reader could not load."); const result = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() }); const text = result.value.replace(/\n{3,}/g, "\n\n").trim(); if (!text) throw new Error(`${file.name} contains no readable text.`); return text; }
  async function handleSubmit(event) {
    event.preventDefault(); els.formMessage.textContent = ""; els.saveButton.disabled = true;
    try {
      const manualTags = els.manualTags.value;
      if (state.mode === "docx") {
        const files = [...els.docxInput.files]; if (!files.length) throw new Error("Choose at least one .docx file."); const prepared = [];
        for (const file of files) { if (!file.name.toLowerCase().endsWith(".docx")) throw new Error(`${file.name} is not a .docx file.`); const text = await readDocx(file); if (!isItContent(text)) throw new Error(`${file.name} does not appear to contain IT knowledge. Add IT-specific details and try again.`); prepared.push({ file, text }); }
        for (const { file, text } of prepared) await putArticle({ id: makeId(), kbNumber: await nextKbNumber(), title: deriveTitle(text, file.name), content: text, category: els.categoryInput.value === "auto" ? guessCategory(text) : els.categoryInput.value, tags: extractTags(`${file.name} ${text}`, manualTags), sourceFile: file.name, createdAt: new Date().toISOString() });
        showToast(`${prepared.length} article${prepared.length === 1 ? "" : "s"} imported`);
      } else {
        const title = els.manualTitle.value.trim(), content = els.manualContent.value.trim(); if (!title || !content) throw new Error("Add both a title and article content."); if (!isItContent(`${title} ${content}`)) throw new Error("This does not appear to be an IT article. Add IT-specific details and try again.");
        const article = { id: makeId(), kbNumber: await nextKbNumber(), title, content, category: els.categoryInput.value === "auto" ? guessCategory(`${title} ${content}`) : els.categoryInput.value, tags: extractTags(`${title} ${content}`, manualTags), sourceFile: null, createdAt: new Date().toISOString() }; await putArticle(article); showToast(`${article.kbNumber} saved`);
      }
      els.addForm.reset(); els.fileQueue.replaceChildren(); els.categoryInput.value = "auto"; els.addDialog.close(); render();
    } catch (error) { els.formMessage.textContent = error.message || "The article could not be added."; } finally { els.saveButton.disabled = false; }
  }
  function openDetail(id) { const article = state.articles.find((item) => item.id === id); if (!article) return; state.detailId = id; els.detailNumber.textContent = article.kbNumber; els.detailTitle.textContent = article.title; els.detailContent.textContent = article.content; const items = [article.category, ...article.tags.map((tag) => `#${tag}`), `Added ${formatDate(article.createdAt)}`]; if (article.sourceFile) items.push(article.sourceFile); els.detailMeta.replaceChildren(...items.map((value) => { const span = document.createElement("span"); span.textContent = value; return span; })); els.articleDialog.showModal(); }
  async function removeCurrentArticle() { const article = state.articles.find((item) => item.id === state.detailId); if (!article || !confirm(`Delete ${article.kbNumber} — ${article.title}?\n\nThis cannot be undone unless you have a backup.`)) return; await deleteArticle(article.id); els.articleDialog.close(); render(); showToast(`${article.kbNumber} deleted`); }
  async function copyCurrentArticle() { const article = state.articles.find((item) => item.id === state.detailId); if (!article) return; const text = `${article.kbNumber} — ${article.title}\nCategory: ${article.category}\nTags: ${article.tags.join(", ")}\n\n${article.content}`; try { await navigator.clipboard.writeText(text); showToast("Article copied"); } catch { showToast("Copy was blocked by the browser"); } }
  function exportBackup() { const payload = { app: "OpsBase", version: 1, exportedAt: new Date().toISOString(), nextNumber: highestNumber(state.articles) + 1, articles: state.articles }; const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }); const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `opsbase-backup-${new Date().toISOString().slice(0, 10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1000); closeBackupMenu(); showToast("Backup exported"); }
  async function restoreBackup(file) {
    try {
      const payload = JSON.parse(await file.text()); if (payload.app !== "OpsBase" || !Array.isArray(payload.articles)) throw new Error("This is not a valid OpsBase backup."); if (!confirm(`Replace the current library with ${payload.articles.length} backed-up article${payload.articles.length === 1 ? "" : "s"}?`)) return;
      const valid = payload.articles.filter((x) => x && typeof x.id === "string" && typeof x.kbNumber === "string" && typeof x.title === "string" && typeof x.content === "string" && CATEGORIES.includes(x.category) && Array.isArray(x.tags)); if (valid.length !== payload.articles.length) throw new Error("The backup contains invalid article data.");
      const tx = db.transaction([STORE, META], "readwrite"), store = tx.objectStore(STORE); store.clear(); valid.forEach((item) => store.put(item)); tx.objectStore(META).put({ key: "nextNumber", value: Math.max(payload.nextNumber || 1, highestNumber(valid) + 1) }); await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); await loadArticles(); render(); showToast("Backup restored");
    } catch (error) { showToast(error.message || "Backup could not be restored"); } finally { els.backupFileInput.value = ""; }
  }
  function closeBackupMenu() { els.backupMenu.hidden = true; els.backupMenuButton.setAttribute("aria-expanded", "false"); }
  function showToast(message) { els.toast.textContent = message; els.toast.classList.add("show"); clearTimeout(showToast.timer); showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 2300); }
  function bindEvents() {
    [els.addButton, els.secondaryAddButton, els.emptyAddButton].forEach((button) => button.addEventListener("click", openAddDialog)); els.addClose.addEventListener("click", () => els.addDialog.close()); els.cancelAddButton.addEventListener("click", () => els.addDialog.close()); $$('.mode-tabs button').forEach((button) => button.addEventListener("click", () => setMode(button.dataset.mode))); els.docxInput.addEventListener("change", renderFileQueue);
    ["dragenter", "dragover"].forEach((name) => els.dropZone.addEventListener(name, (event) => { event.preventDefault(); els.dropZone.classList.add("dragging"); })); ["dragleave", "drop"].forEach((name) => els.dropZone.addEventListener(name, (event) => { event.preventDefault(); els.dropZone.classList.remove("dragging"); })); els.dropZone.addEventListener("drop", (event) => { if (event.dataTransfer.files.length) { els.docxInput.files = event.dataTransfer.files; renderFileQueue(); } });
    els.addForm.addEventListener("submit", handleSubmit); els.searchInput.addEventListener("input", () => { state.query = els.searchInput.value; render(); }); els.sortSelect.addEventListener("change", () => { state.sort = els.sortSelect.value; render(); }); $('.filter-item[data-category="all"]').addEventListener("click", () => { state.category = "all"; render(); }); els.clearFilters.addEventListener("click", () => { state.category = "all"; state.tag = ""; state.query = ""; els.searchInput.value = ""; render(); }); document.addEventListener("keydown", (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); els.searchInput.focus(); } });
    els.detailClose.addEventListener("click", () => els.articleDialog.close()); els.deleteButton.addEventListener("click", removeCurrentArticle); els.copyButton.addEventListener("click", copyCurrentArticle); els.backupMenuButton.addEventListener("click", () => { const opening = els.backupMenu.hidden; els.backupMenu.hidden = !opening; els.backupMenuButton.setAttribute("aria-expanded", String(opening)); }); els.exportButton.addEventListener("click", exportBackup); els.importButton.addEventListener("click", () => { closeBackupMenu(); els.backupFileInput.click(); }); els.backupFileInput.addEventListener("change", () => { if (els.backupFileInput.files[0]) restoreBackup(els.backupFileInput.files[0]); }); document.addEventListener("click", (event) => { if (!els.backupMenu.contains(event.target) && event.target !== els.backupMenuButton) closeBackupMenu(); });
  }
  async function init() {
    ["kbCount", "tagCount", "updatedText", "allCount", "categoryList", "tagCloud", "searchInput", "sortSelect", "resultCount", "activeFilterText", "articleList", "emptyState", "addButton", "secondaryAddButton", "emptyAddButton", "clearFilters", "addDialog", "addForm", "addClose", "cancelAddButton", "docxPanel", "manualPanel", "docxInput", "dropZone", "fileQueue", "manualTitle", "manualContent", "categoryInput", "manualTags", "formMessage", "saveButton", "articleDialog", "detailNumber", "detailTitle", "detailMeta", "detailContent", "detailClose", "deleteButton", "copyButton", "backupMenuButton", "backupMenu", "exportButton", "importButton", "backupFileInput", "toast"].forEach((id) => { els[id] = document.getElementById(id); });
    CATEGORIES.forEach((category) => { const option = document.createElement("option"); option.value = category; option.textContent = category; els.categoryInput.append(option); }); const auto = document.createElement("option"); auto.value = "auto"; auto.textContent = "Auto-detect"; els.categoryInput.prepend(auto); els.categoryInput.value = "auto";
    try { db = await openDatabase(); await loadArticles(); bindEvents(); render(); } catch (error) { console.error(error); alert("OpsBase could not open local browser storage. Check that private browsing is off and reload the page."); }
  }
  init();
})();
