OPSBASE — LOCAL IT KNOWLEDGE BASE
=================================

START
1. Keep this entire folder together.
2. Double-click index.html to open OpsBase in a current version of Chrome,
   Edge, Firefox, or Safari.
3. Choose "Add knowledge" to import one or more .docx files or write an
   article manually.

YOUR DATA
- Articles are stored in this browser on this device. No server or internet
  connection is used.
- Each article gets a permanent sequential number such as KB-000001.
- Removing an article does not reuse its KB number.
- Use the three-dot menu to export a JSON backup regularly.
- Restoring a backup replaces the library currently stored in that browser.

IMPORTANT
- Browser storage belongs to the exact browser and location used to open the
  app. Moving the folder or using a different browser can show a separate,
  empty library. Export a backup before moving it.
- Clearing site/browser data can remove the library. Keep backup files in a
  safe location.
- Word import supports .docx files. Legacy .doc files should first be saved as
  .docx in Microsoft Word or LibreOffice.
